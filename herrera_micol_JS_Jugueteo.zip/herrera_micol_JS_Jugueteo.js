
var alturaNiño = 55; 

function muestraSiElNiñoPuedeSubirALaMontañaRusa() {
    if (alturaNiño > 52) {
        console.log("¡Súbete, chico!");
    } else {
        console.log("Lo siento, chico. Tal vez el próximo año.");
    }
}

muestraSiElNiñoPuedeSubirALaMontañaRusa();
